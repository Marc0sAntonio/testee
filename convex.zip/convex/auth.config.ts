// https://fresh-ladybug-48.clerk.accounts.dev

export default {
    providers: [
      {
        domain: "https://fresh-ladybug-48.clerk.accounts.dev",
        applicationID: "convex",
      },
    ]
  }; // this makes the auth.config.ts file a module